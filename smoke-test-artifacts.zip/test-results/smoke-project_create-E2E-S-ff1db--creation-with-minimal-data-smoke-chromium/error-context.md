# Page snapshot

```yaml
- generic [ref=e4]:
  - generic [ref=e5]:
    - img [ref=e7]
    - heading "Sign in to your account" [level=2] [ref=e9]
    - paragraph [ref=e10]:
      - text: Or
      - link "create a new account" [ref=e11] [cursor=pointer]:
        - /url: http://127.0.0.1:8000/register
  - generic [ref=e12]:
    - generic [ref=e13]:
      - generic [ref=e14]:
        - text: Email address
        - textbox "Email address" [ref=e15]
      - generic [ref=e16]:
        - text: Password
        - textbox "Password" [ref=e17]
        - button [ref=e18]:
          - img [ref=e19]
          - img [ref=e22]
    - generic [ref=e24]:
      - generic [ref=e25]:
        - checkbox "Remember me" [ref=e26]
        - text: Remember me
      - link "Forgot your password?" [ref=e28] [cursor=pointer]:
        - /url: http://127.0.0.1:8000/password/reset
    - button "Sign in" [ref=e30]:
      - img [ref=e32]
      - text: Sign in
      - img [ref=e34]
```