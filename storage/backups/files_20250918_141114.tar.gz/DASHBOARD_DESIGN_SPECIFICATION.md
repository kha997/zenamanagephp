# 🎨 THIẾT KẾ UI DASHBOARD CHO TỪNG ROLE

## 📋 TỔNG QUAN HỆ THỐNG ROLE

Hệ thống ZENA Management có **7 role chính** với quyền hạn và trách nhiệm khác nhau:

### 🔐 **Phân quyền theo Role:**

| Role | Quyền hạn chính | Phạm vi truy cập |
|------|----------------|------------------|
| **System Admin** | Full quyền hệ thống | Toàn bộ hệ thống |
| **Project Manager** | Quản lý dự án, CR, Baseline | Dự án được assign |
| **Design Lead** | Phát hành bản vẽ, RFI/Submittal | Module thiết kế |
| **Site Engineer** | Nhật ký, nghiệm thu, ảnh hiện trường | Module hiện trường |
| **QC/QA Inspector** | Kiểm định, checklist, NCR | Module chất lượng |
| **Client Rep** | Duyệt CR, duyệt hồ sơ | Module khách hàng |
| **Subcontractor Lead** | Cập nhật tiến độ, submit vật tư | Module nhà thầu |

---

## 🎯 **THIẾT KẾ DASHBOARD CHO TỪNG ROLE**

### 1️⃣ **SYSTEM ADMIN DASHBOARD**

#### 🎨 **Layout & Components:**
```
┌─────────────────────────────────────────────────────────────┐
│ 🏢 ZENA Management System                    👤 Admin User   │
├─────────────────────────────────────────────────────────────┤
│ 📊 SYSTEM OVERVIEW                                          │
│ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────┐ │
│ │ Total Users │ │ Active Proj │ │ System Load │ │ Alerts  │ │
│ │    1,247    │ │     23      │ │    78%      │ │    3    │ │
│ └─────────────┘ └─────────────┘ └─────────────┘ └─────────┘ │
├─────────────────────────────────────────────────────────────┤
│ 📈 SYSTEM METRICS                                          │
│ ┌─────────────────────────────────────────────────────────┐ │
│ │ 📊 User Growth Chart (Last 6 months)                    │ │
│ │ 📊 Project Completion Rate                              │ │
│ │ 📊 System Performance Metrics                           │ │
│ └─────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────┤
│ 🔧 SYSTEM MANAGEMENT                                        │
│ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────┐ │
│ │ 👥 Users    │ │ 🏗️ Projects │ │ ⚙️ Settings │ │ 📋 Logs │ │
│ │ Management  │ │ Management  │ │ & Config    │ │ & Audit │ │
│ └─────────────┘ └─────────────┘ └─────────────┘ └─────────┘ │
└─────────────────────────────────────────────────────────────┘
```

#### 🎯 **Key Features:**
- **System Overview**: Tổng quan toàn hệ thống
- **User Management**: Quản lý người dùng và phân quyền
- **Project Management**: Quản lý tất cả dự án
- **System Monitoring**: Giám sát hiệu suất hệ thống
- **Audit Trail**: Theo dõi mọi hoạt động
- **Configuration**: Cấu hình hệ thống

#### 📊 **Metrics & KPIs:**
- Total Users, Active Projects, System Load
- User Growth Rate, Project Completion Rate
- System Performance, Error Rates
- Security Alerts, Failed Logins

---

### 2️⃣ **PROJECT MANAGER DASHBOARD**

#### 🎨 **Layout & Components:**
```
┌─────────────────────────────────────────────────────────────┐
│ 🏗️ Project Dashboard                    👤 PM User          │
├─────────────────────────────────────────────────────────────┤
│ 📊 PROJECT OVERVIEW                                        │
│ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────┐ │
│ │ Total Tasks │ │ Completed   │ │ Budget Used │ │ Timeline│ │
│ │    156      │ │    89%      │ │    67%      │ │ On Track│ │
│ └─────────────┘ └─────────────┘ └─────────────┘ └─────────┘ │
├─────────────────────────────────────────────────────────────┤
│ 📈 PROJECT PROGRESS                                        │
│ ┌─────────────────────────────────────────────────────────┐ │
│ │ 📊 Gantt Chart - Project Timeline                       │ │
│ │ 📊 Budget vs Actual Cost Chart                          │ │
│ │ 📊 Task Completion Status                                │ │
│ └─────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────┤
│ 🔧 PROJECT MANAGEMENT                                       │
│ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────┐ │
│ │ 📋 Tasks    │ │ 🔄 CRs     │ │ 📝 RFIs     │ │ 📊 Reports│ │
│ │ Management  │ │ Management │ │ Management  │ │ & Analytics│ │
│ └─────────────┘ └─────────────┘ └─────────────┘ └─────────┘ │
├─────────────────────────────────────────────────────────────┤
│ 🚨 ALERTS & NOTIFICATIONS                                   │
│ • Task overdue: 3 tasks need attention                     │
│ • Budget alert: 85% budget used                            │
│ • CR pending: 2 change requests waiting approval           │
└─────────────────────────────────────────────────────────────┘
```

#### 🎯 **Key Features:**
- **Project Overview**: Tổng quan dự án được assign
- **Task Management**: Quản lý tasks và dependencies
- **Change Request Management**: Xử lý CR và approval
- **Budget Tracking**: Theo dõi ngân sách và chi phí
- **Timeline Management**: Quản lý tiến độ dự án
- **Team Management**: Quản lý team members

#### 📊 **Metrics & KPIs:**
- Project Progress, Task Completion Rate
- Budget Utilization, Cost Performance Index
- Schedule Performance Index, Risk Level
- Team Productivity, Quality Metrics

---

### 3️⃣ **DESIGN LEAD DASHBOARD**

#### 🎨 **Layout & Components:**
```
┌─────────────────────────────────────────────────────────────┐
│ 🎨 Design Dashboard                   👤 Design Lead        │
├─────────────────────────────────────────────────────────────┤
│ 📊 DESIGN OVERVIEW                                         │
│ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────┐ │
│ │ Drawings    │ │ RFIs        │ │ Submittals  │ │ Reviews │ │
│ │    45       │ │    12       │ │     8       │ │    3    │ │
│ └─────────────┘ └─────────────┘ └─────────────┘ └─────────┘ │
├─────────────────────────────────────────────────────────────┤
│ 📈 DESIGN PROGRESS                                         │
│ ┌─────────────────────────────────────────────────────────┐ │
│ │ 📊 Drawing Release Schedule                             │ │
│ │ 📊 RFI Response Time Chart                              │ │
│ │ 📊 Submittal Approval Status                            │ │
│ └─────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────┤
│ 🔧 DESIGN MANAGEMENT                                        │
│ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────┐ │
│ │ 📐 Drawings │ │ ❓ RFIs     │ │ 📋 Submittals│ │ 📝 Reviews│ │
│ │ Management  │ │ Management  │ │ Management  │ │ & Approval│ │
│ └─────────────┘ └─────────────┘ └─────────────┘ └─────────┘ │
├─────────────────────────────────────────────────────────────┤
│ 🚨 DESIGN ALERTS                                           │
│ • RFI overdue: 2 RFIs need response within 24h            │
│ • Drawing review: 3 drawings pending review               │
│ • Submittal approval: 1 submittal waiting approval        │
└─────────────────────────────────────────────────────────────┘
```

#### 🎯 **Key Features:**
- **Drawing Management**: Quản lý bản vẽ và revisions
- **RFI Management**: Xử lý Request for Information
- **Submittal Management**: Quản lý hồ sơ submit
- **Design Review**: Review và approval process
- **Version Control**: Quản lý phiên bản bản vẽ
- **Design Standards**: Tuân thủ tiêu chuẩn thiết kế

#### 📊 **Metrics & KPIs:**
- Drawing Release Rate, RFI Response Time
- Submittal Approval Rate, Design Quality Score
- Revision Frequency, Design Error Rate
- Client Satisfaction, Design Team Productivity

---

### 4️⃣ **SITE ENGINEER DASHBOARD**

#### 🎨 **Layout & Components:**
```
┌─────────────────────────────────────────────────────────────┐
│ 🏗️ Site Dashboard                    👤 Site Engineer       │
├─────────────────────────────────────────────────────────────┤
│ 📊 SITE OVERVIEW                                          │
│ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────┐ │
│ │ Daily       │ │ Photos      │ │ Inspections │ │ Weather │ │
│ │ Reports     │ │ Uploaded    │ │ Completed   │ │ Status  │ │
│ │    15       │ │    23       │ │     8       │ │   ☀️    │ │
│ └─────────────┘ └─────────────┘ └─────────────┘ └─────────┘ │
├─────────────────────────────────────────────────────────────┤
│ 📈 SITE PROGRESS                                           │
│ ┌─────────────────────────────────────────────────────────┐ │
│ │ 📊 Daily Progress Chart                                 │ │
│ │ 📊 Photo Gallery - Latest Site Photos                   │ │
│ │ 📊 Weather Impact Analysis                              │ │
│ └─────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────┤
│ 🔧 SITE MANAGEMENT                                         │
│ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────┐ │
│ │ 📝 Daily    │ │ 📸 Photos   │ │ 🔍 Inspections│ │ 👥 Manpower│ │
│ │ Reports     │ │ & Media     │ │ & Quality   │ │ Tracking │ │
│ └─────────────┘ └─────────────┘ └─────────────┘ └─────────┘ │
├─────────────────────────────────────────────────────────────┤
│ 🚨 SITE ALERTS                                             │
│ • Weather alert: Rain expected tomorrow                    │
│ • Inspection due: Foundation inspection scheduled          │
│ • Safety concern: 1 safety incident reported              │
└─────────────────────────────────────────────────────────────┘
```

#### 🎯 **Key Features:**
- **Daily Reports**: Báo cáo hàng ngày về tiến độ
- **Photo Management**: Upload và quản lý ảnh hiện trường
- **Inspection Management**: Quản lý nghiệm thu và kiểm tra
- **Weather Tracking**: Theo dõi thời tiết và tác động
- **Manpower Tracking**: Theo dõi nhân lực và thiết bị
- **Safety Management**: Quản lý an toàn lao động

#### 📊 **Metrics & KPIs:**
- Daily Progress Rate, Photo Upload Count
- Inspection Completion Rate, Weather Impact
- Manpower Utilization, Safety Incident Rate
- Quality Score, Client Satisfaction

---

### 5️⃣ **QC/QA INSPECTOR DASHBOARD**

#### 🎨 **Layout & Components:**
```
┌─────────────────────────────────────────────────────────────┐
│ 🔍 QC Dashboard                      👤 QC Inspector        │
├─────────────────────────────────────────────────────────────┤
│ 📊 QUALITY OVERVIEW                                       │
│ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────┐ │
│ │ Inspections │ │ NCRs        │ │ Observations│ │ Quality │ │
│ │    24       │ │    3        │ │     7       │ │ Score   │ │
│ └─────────────┘ └─────────────┘ └─────────────┘ └─────────┘ │
├─────────────────────────────────────────────────────────────┤
│ 📈 QUALITY PROGRESS                                        │
│ ┌─────────────────────────────────────────────────────────┐ │
│ │ 📊 Quality Trend Chart                                  │ │
│ │ 📊 NCR Status Distribution                              │ │
│ │ 📊 Inspection Results Summary                           │ │
│ └─────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────┤
│ 🔧 QUALITY MANAGEMENT                                      │
│ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────┐ │
│ │ 🔍 Inspections│ │ ⚠️ NCRs     │ │ 📋 Checklists│ │ 📊 Reports│ │
│ │ Management  │ │ Management  │ │ Management  │ │ & Analytics│ │
│ └─────────────┘ └─────────────┘ └─────────────┘ └─────────┘ │
├─────────────────────────────────────────────────────────────┤
│ 🚨 QUALITY ALERTS                                         │
│ • NCR overdue: 1 NCR needs corrective action             │
│ • Inspection due: 2 inspections scheduled today           │
│ • Quality concern: 1 observation needs attention          │
└─────────────────────────────────────────────────────────────┘
```

#### 🎯 **Key Features:**
- **Inspection Management**: Quản lý kiểm tra và nghiệm thu
- **NCR Management**: Xử lý Non-Conformance Reports
- **Checklist Management**: Quản lý checklist kiểm tra
- **Quality Reports**: Báo cáo chất lượng và phân tích
- **Corrective Actions**: Quản lý hành động khắc phục
- **Quality Standards**: Tuân thủ tiêu chuẩn chất lượng

#### 📊 **Metrics & KPIs:**
- Inspection Completion Rate, NCR Resolution Time
- Quality Score, Defect Rate
- Corrective Action Effectiveness, Compliance Rate
- Client Satisfaction, Quality Trend

---

### 6️⃣ **CLIENT REP DASHBOARD**

#### 🎨 **Layout & Components:**
```
┌─────────────────────────────────────────────────────────────┐
│ 👔 Client Dashboard                  👤 Client Rep         │
├─────────────────────────────────────────────────────────────┤
│ 📊 PROJECT STATUS                                         │
│ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────┐ │
│ │ CRs         │ │ Approvals   │ │ Budget      │ │ Timeline│ │
│ │ Pending     │ │ Required    │ │ Status      │ │ Status  │ │
│ │    5        │ │    3        │ │ On Track    │ │ On Track│ │
│ └─────────────┘ └─────────────┘ └─────────────┘ └─────────┘ │
├─────────────────────────────────────────────────────────────┤
│ 📈 PROJECT OVERVIEW                                        │
│ ┌─────────────────────────────────────────────────────────┐ │
│ │ 📊 Project Progress Summary                             │ │
│ │ 📊 Budget vs Actual Chart                               │ │
│ │ 📊 Timeline Milestone Status                            │ │
│ └─────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────┤
│ 🔧 CLIENT MANAGEMENT                                       │
│ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────┐ │
│ │ 🔄 CRs      │ │ 📋 Reports  │ │ 📝 Reviews  │ │ 📊 Analytics│ │
│ │ Approval    │ │ & Updates  │ │ & Feedback  │ │ & Insights│ │
│ └─────────────┘ └─────────────┘ └─────────────┘ └─────────┘ │
├─────────────────────────────────────────────────────────────┤
│ 🚨 CLIENT ALERTS                                           │
│ • CR approval: 2 change requests need your approval       │
│ • Budget alert: Project approaching budget limit           │
│ • Timeline concern: 1 milestone at risk                   │
└─────────────────────────────────────────────────────────────┘
```

#### 🎯 **Key Features:**
- **Change Request Approval**: Duyệt và phê duyệt CR
- **Project Monitoring**: Theo dõi tiến độ dự án
- **Budget Oversight**: Giám sát ngân sách và chi phí
- **Report Review**: Xem và phản hồi báo cáo
- **Communication**: Giao tiếp với team dự án
- **Decision Making**: Đưa ra quyết định quan trọng

#### 📊 **Metrics & KPIs:**
- CR Approval Rate, Decision Time
- Budget Performance, Cost Variance
- Timeline Adherence, Milestone Achievement
- Communication Effectiveness, Satisfaction Score

---

### 7️⃣ **SUBCONTRACTOR LEAD DASHBOARD**

#### 🎨 **Layout & Components:**
```
┌─────────────────────────────────────────────────────────────┐
│ 🏗️ Subcontractor Dashboard         👤 Subcontractor Lead   │
├─────────────────────────────────────────────────────────────┤
│ 📊 WORK OVERVIEW                                          │
│ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────┐ │
│ │ Tasks       │ │ Materials   │ │ Progress    │ │ Quality │ │
│ │ Assigned    │ │ Submitted   │ │ Updates     │ │ Score   │ │
│ │    12       │ │     8       │ │    85%      │ │   92%   │ │
│ └─────────────┘ └─────────────┘ └─────────────┘ └─────────┘ │
├─────────────────────────────────────────────────────────────┤
│ 📈 WORK PROGRESS                                           │
│ ┌─────────────────────────────────────────────────────────┐ │
│ │ 📊 Task Completion Chart                                │ │
│ │ 📊 Material Submission Status                           │ │
│ │ 📊 Quality Performance Trend                            │ │
│ └─────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────┤
│ 🔧 WORK MANAGEMENT                                         │
│ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────┐ │
│ │ 📋 Tasks    │ │ 📦 Materials│ │ 📝 Reports  │ │ 📊 Analytics│ │
│ │ Management  │ │ Submission │ │ & Updates   │ │ & Performance│ │
│ └─────────────┘ └─────────────┘ └─────────────┘ └─────────┘ │
├─────────────────────────────────────────────────────────────┤
│ 🚨 WORK ALERTS                                            │
│ • Task overdue: 2 tasks need completion                   │
│ • Material submission: 1 material package pending review  │
│ • Quality concern: 1 quality issue needs attention       │
└─────────────────────────────────────────────────────────────┘
```

#### 🎯 **Key Features:**
- **Task Management**: Quản lý tasks được assign
- **Material Submission**: Submit vật tư và biện pháp
- **Progress Updates**: Cập nhật tiến độ công việc
- **Quality Management**: Đảm bảo chất lượng công việc
- **Resource Management**: Quản lý nhân lực và thiết bị
- **Communication**: Giao tiếp với PM và team

#### 📊 **Metrics & KPIs:**
- Task Completion Rate, Material Submission Rate
- Progress Accuracy, Quality Score
- Resource Utilization, Communication Effectiveness
- Client Satisfaction, Performance Rating

---

## 🎨 **THIẾT KẾ UI/UX CHUNG**

### 🎯 **Design Principles:**
1. **Role-Based Access**: Mỗi role có dashboard riêng phù hợp
2. **Consistent Layout**: Layout nhất quán nhưng nội dung khác nhau
3. **Progressive Disclosure**: Thông tin được hiển thị theo mức độ quan trọng
4. **Mobile Responsive**: Tối ưu cho mọi thiết bị
5. **Accessibility**: Tuân thủ chuẩn accessibility

### 🎨 **Color Scheme:**
- **Primary**: ZENA Blue (#1E40AF)
- **Secondary**: Construction Orange (#F59E0B)
- **Success**: Green (#10B981)
- **Warning**: Yellow (#F59E0B)
- **Error**: Red (#EF4444)
- **Info**: Blue (#3B82F6)

### 📱 **Responsive Design:**
- **Desktop**: Full dashboard với sidebar
- **Tablet**: Collapsible sidebar
- **Mobile**: Bottom navigation với drawer

### 🔔 **Notification System:**
- **In-app**: Toast notifications
- **Email**: Email alerts
- **Push**: Browser push notifications
- **SMS**: Critical alerts only

---

## 🚀 **IMPLEMENTATION ROADMAP**

### Phase 1: Core Dashboard (2 weeks)
- System Admin Dashboard
- Project Manager Dashboard
- Basic responsive design

### Phase 2: Role-Specific Dashboards (3 weeks)
- Design Lead Dashboard
- Site Engineer Dashboard
- QC Inspector Dashboard

### Phase 3: Client & Subcontractor (2 weeks)
- Client Rep Dashboard
- Subcontractor Lead Dashboard
- Advanced features

### Phase 4: Polish & Optimization (1 week)
- Performance optimization
- Accessibility improvements
- User testing & feedback

---

**Tổng thời gian dự kiến: 8 tuần**
